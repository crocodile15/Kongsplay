# Kongsplay

A simple Android video player app built with Java.
